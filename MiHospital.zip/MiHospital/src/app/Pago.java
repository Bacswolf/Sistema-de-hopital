/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author taz
 */
public class Pago extends javax.swing.JFrame {
    
    public static final String URL = "jdbc:mysql://localhost:3306/hospital";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    PreparedStatement ps;
    ResultSet rs;

    public static Connection getConection() {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            System.out.println(e);
        }

        return con;
    }

    public void generarCombo(JComboBox cbx, String s, String i) {
        Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("SELECT " + i + ",nombre FROM " + s);
            ResultSet result = ps.executeQuery();

            if (result.next()) {
                result.beforeFirst();
                cbx.addItem("Selecciona");
                while (result.next()) {
                    cbx.addItem(result.getString(i) + " " + result.getString("Nombre"));
                }
            } else {
                JOptionPane.showMessageDialog(null, "La tabla " + s + " esta vacia!");
            }

        } catch (Exception e) {
        }
    }
    
    /**
     * Creates new form Pago
     */
    public Pago() {
        initComponents();
        generarCombo(cbxemp, "empleados", "id_empleado");
        generarCombo(cbxcar, "cargos", "id_cargo");
    }
    
    private void limpiarCaja(){
        txtid.setText("");
        txtfi.setText("");
        txtff.setText("");
        txtlab.setText("");
        txttp.setText("");
        txttd.setText("");
        txtnp.setText("");
        txtsb.setText("");
        cbxcar.setSelectedIndex(0);
        cbxemp.setSelectedIndex(0);
    }
    private void guardarDatos() throws SQLException{
       Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("insert into pago (fecha_inicio,fecha_fin,DiasLaborados,totalpercepciones,totaldeducciones,id_Empleado,Id_cargo,netopagado,sueldobruto) values (?,?,?,?,?,?,?,?,?)");
            ps.setString(1, txtfi.getText());
            ps.setString(2, txtff.getText());
            ps.setString(3, txtlab.getText());
            ps.setFloat(4,Float.parseFloat( txttp.getText()));
            ps.setFloat(5,Float.parseFloat(  txttd.getText()));
            String a=(cbxemp.getSelectedItem().toString());
            ps.setString(6, a.substring(0,a.indexOf(' ')));
            a=(cbxcar.getSelectedItem().toString());
            ps.setString(7, a.substring(0,a.indexOf(' ')));
            ps.setFloat(8,Float.parseFloat(txtnp.getText()));
            ps.setFloat(9,Float.parseFloat(txtsb.getText()));
            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "El pago se registro con éxito!");
                limpiarCaja();
            }else{
               JOptionPane.showMessageDialog(null, "Hubo un error al guardar!"); 
            }
            con.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
    public void eliminarDatos(){
        Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("delete from pago where id_pago= ?");
            ps.setString(1, txtid.getText());
            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Se elimino el pago con clave: "+txtid.getText() + " de forma exitosa!"); 
              limpiarCaja();
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al eliminar!"); 
            }
            con.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
    public void buscarDatos(){
         Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("select * from pago where id_pago = ?");
            ps.setString(1, txtid.getText());
            rs = ps.executeQuery();
            if (rs.next() ) {
                txtfi.setText(rs.getString("fecha_inicio"));
                txtff.setText(rs.getString("fecha_fin"));
                txtlab.setText(rs.getString("DiasLaborados"));
                txttp.setText(rs.getString("totalpercepciones"));
                txttd.setText(rs.getString("totaldeducciones"));
                txtnp.setText(rs.getString("netopagado"));
                txtsb.setText(rs.getString("totaldeducciones"));
                for(int i=1;i<cbxemp.getItemCount();i++){
                    String a=cbxemp.getItemAt(i);
                    if(rs.getString("id_Empleado").equals(a.substring(0,a.indexOf(' ')))){
                        cbxemp.setSelectedIndex(i);
                        break;
                    }
                }
                for(int i=1;i<cbxcar.getItemCount();i++){
                    String a=cbxcar.getItemAt(i);
                    if(rs.getString("Id_cargo").equals(a.substring(0,a.indexOf(' ')))){
                        cbxcar.setSelectedIndex(i);
                        break;
                    }
                }
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al buscar!"); 
            }
            
            con.close();
            
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
    public void actualizarDatos() throws SQLException{
        Connection con = null;
        try{
            con = getConection();
            ps = con.prepareStatement("update pago set fecha_inicio=?,fecha_fin=?,DiasLaborados=?,totalpercepciones=?,totaldeducciones=?,id_Empleado=?,Id_cargo=?,netopagado=?,sueldobruto=? where id_pago=?");
            ps.setInt(10, Integer.parseInt(txtid.getText()));
            ps.setString(1, txtfi.getText());
            ps.setString(2, txtff.getText());
            ps.setString(3, txtlab.getText());
            ps.setFloat(4,Float.parseFloat( txttp.getText()));
            ps.setFloat(5,Float.parseFloat(  txttd.getText()));
            String a=(cbxemp.getSelectedItem().toString());
            ps.setString(6, a.substring(0,a.indexOf(' ')));
            a=(cbxcar.getSelectedItem().toString());
            ps.setString(7, a.substring(0,a.indexOf(' ')));
            ps.setFloat(8,Float.parseFloat(txtnp.getText()));
            ps.setFloat(9,Float.parseFloat(txtsb.getText()));
            int res = ps.executeUpdate();
            if(res>0){
                JOptionPane.showMessageDialog(null, "pago modificado"); //Hospital modificado
                limpiarCaja();
            }
            else{
                JOptionPane.showMessageDialog(null, "Error al Modificar pago");
                limpiarCaja();
            }
        con.close();
        }
        
        catch (Exception e) {
            System.err.println(e);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        txtfi = new javax.swing.JTextField();
        txtff = new javax.swing.JTextField();
        txtlab = new javax.swing.JTextField();
        txttp = new javax.swing.JTextField();
        txttd = new javax.swing.JTextField();
        txtnp = new javax.swing.JTextField();
        txtsb = new javax.swing.JTextField();
        cbxemp = new javax.swing.JComboBox<>();
        cbxcar = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Id pago");

        jLabel2.setText("Fecha Inicio");

        jLabel3.setText("Fecha fin");

        jLabel4.setText("dias laborales");

        jLabel5.setText("total persepciones");

        jLabel6.setText("total deducciones ");

        jLabel7.setText("Id Empleado");

        jLabel8.setText("Id Cargo");

        jLabel9.setText("Neto Pagado");

        jLabel10.setText("Sueldo bruto");

        txtfi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfiActionPerformed(evt);
            }
        });

        txtff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtffActionPerformed(evt);
            }
        });

        txtlab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlabActionPerformed(evt);
            }
        });

        txttp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttpActionPerformed(evt);
            }
        });

        txttd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttdActionPerformed(evt);
            }
        });

        txtnp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnpActionPerformed(evt);
            }
        });

        txtsb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsbActionPerformed(evt);
            }
        });

        jButton5.setText("Limpiar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Buscar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Actualizar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Eliminar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbxcar, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtsb, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                                        .addComponent(txtnp, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                                        .addComponent(txttd, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                                        .addComponent(cbxemp, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel4))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtlab, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txttp, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(txtfi, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(54, 54, 54)
                                            .addComponent(txtff, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addComponent(jButton4)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton5)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtfi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtlab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txttp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txttd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cbxemp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(cbxcar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtnp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtsb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtfiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfiActionPerformed

    private void txtffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtffActionPerformed

    private void txtlabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtlabActionPerformed

    private void txttpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttpActionPerformed

    private void txttdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttdActionPerformed

    private void txtnpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnpActionPerformed

    private void txtsbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsbActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        limpiarCaja();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            guardarDatos();
        } catch (SQLException ex) {
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        buscarDatos();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            actualizarDatos();
        } catch (SQLException ex) {
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        eliminarDatos();
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxcar;
    private javax.swing.JComboBox<String> cbxemp;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtff;
    private javax.swing.JTextField txtfi;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtlab;
    private javax.swing.JTextField txtnp;
    private javax.swing.JTextField txtsb;
    private javax.swing.JTextField txttd;
    private javax.swing.JTextField txttp;
    // End of variables declaration//GEN-END:variables
}
