/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author taz
 */
public class Cuentacita extends javax.swing.JFrame {

    public static final String URL = "jdbc:mysql://localhost:3306/hospital";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    PreparedStatement ps;
    ResultSet rs;

    public static Connection getConection() {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            System.out.println(e);
        }

        return con;
    }

    public void generarCombo(JComboBox cbx, String s, String i) {
        Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("SELECT " + i + ",nombre FROM " + s);
            ResultSet result = ps.executeQuery();

            if (result.next()) {
                result.beforeFirst();
                cbx.addItem("Selecciona");
                while (result.next()) {
                    cbx.addItem(result.getString(i) + " " + result.getString("Nombre"));
                }
            } else {
                JOptionPane.showMessageDialog(null, "La tabla " + s + " esta vacia!");
            }

        } catch (Exception e) {
        }
    }
    
    /**
     * Creates new form Cuentacita
     */
    public Cuentacita() {
        initComponents();
        generarCombo(cbxmed, "medicamentos", "idMedicamento");
        generarCombo(cbxmat, "material", "idMaterial");
        generarCombo(cbxemp, "empleados", "id_empleado");
        generarCombo(cbxser, "servicios", "id_servicios");
        generarCombo(cbxesp, "especialidad", "idEspecialidad");
    }
    
    private void limpiarCaja(){
        txtid.setText("");
        txtcita.setText("");
        cbxemp.setSelectedIndex(0);
        cbxesp.setSelectedIndex(0);
        cbxmat.setSelectedIndex(0);
        cbxmed.setSelectedIndex(0);
        cbxser.setSelectedIndex(0);
    }
    
    private void guardarDatos() throws SQLException{
       Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("insert into cuentacita ( idCita,idMedicamento,idMaterial,idEmpleado,idServicio,idEspecialidad) values (?,?,?,?,?,?)");
            ps.setString(1, txtcita.getText());
            String a=(cbxmed.getSelectedItem().toString());
            ps.setString(2, a.substring(0,a.indexOf(' ')));
            a=(cbxmat.getSelectedItem().toString());
            ps.setString(3, a.substring(0,a.indexOf(' ')));
            a=(cbxemp.getSelectedItem().toString());
            ps.setString(4, a.substring(0,a.indexOf(' ')));
            a=(cbxser.getSelectedItem().toString());
            ps.setString(5, a.substring(0,a.indexOf(' ')));
            a=(cbxesp.getSelectedItem().toString());
            ps.setString(6, a.substring(0,a.indexOf(' ')));
            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "La cuenta cita se registro con éxito!");
                limpiarCaja();
            }else{
               JOptionPane.showMessageDialog(null, "Hubo un error al guardar!"); 
            }
            con.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    
    public void eliminarDatos(){
        Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("delete from cuentacita where idCuentaCita = ?");
            ps.setString(1, txtid.getText());
            int res = ps.executeUpdate();
            if (res > 0) {
              JOptionPane.showMessageDialog(null, "Se elimino la cuenta cita con clave: "+txtid.getText() + " de forma exitosa!"); 
              limpiarCaja();
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al eliminar!"); 
            }
            con.close();
        } catch (Exception e) {
        }
    }
    
    public void buscarDatos(){
         Connection con = null;
        try {
            con = getConection();
            ps = con.prepareStatement("select * from cuentacita where idCuentaCita = ?");
            ps.setString(1, txtid.getText());
            rs = ps.executeQuery();
            if (rs.next() ) {
                txtcita.setText(rs.getString("idCita"));
                for(int i=1;i<cbxmed.getItemCount();i++){
                    String a=cbxmed.getItemAt(i);
                    if(rs.getString("idMedicamento").equals(a.substring(0,a.indexOf(' ')))){
                        cbxmed.setSelectedIndex(i);
                        break;
                    }
                }
                for(int i=1;i<cbxmat.getItemCount();i++){
                    String a=cbxmat.getItemAt(i);
                    if(rs.getString("idMaterial").equals(a.substring(0,a.indexOf(' ')))){
                        cbxmat.setSelectedIndex(i);
                        break;
                    }
                }
                for(int i=1;i<cbxemp.getItemCount();i++){
                    String a=cbxemp.getItemAt(i);
                    if(rs.getString("IdEmpleado").equals(a.substring(0,a.indexOf(' ')))){
                        cbxemp.setSelectedIndex(i);
                        break;
                    }
                }
                for(int i=1;i<cbxser.getItemCount();i++){
                    String a=cbxser.getItemAt(i);
                    if(rs.getString("idServicio").equals(a.substring(0,a.indexOf(' ')))){
                        cbxser.setSelectedIndex(i);
                        break;
                    }
                }
                for(int i=1;i<cbxesp.getItemCount();i++){
                    String a=cbxesp.getItemAt(i);
                    if(rs.getString("idEspecialidad").equals(a.substring(0,a.indexOf(' ')))){
                        cbxesp.setSelectedIndex(i);
                        break;
                    }
                }
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al buscar!"); 
            }
            con.close();
        } catch (Exception e) {
        }
    }
    public void actualizarDatos() throws SQLException{
        Connection con = null;
        try{
            con = getConection();
            ps = con.prepareStatement("update cuentacita set idCita=?,idMedicamento=?,idMaterial=?,idEmpleado=?,idServicio=?,idEspecialidad=? where idCuentaCita=?");
            ps.setInt(7, Integer.parseInt(txtid.getText()));
            ps.setString(1, txtcita.getText());
            String a=(cbxmed.getSelectedItem().toString());
            ps.setString(2, a.substring(0,a.indexOf(' ')));
            a=(cbxmat.getSelectedItem().toString());
            ps.setString(3, a.substring(0,a.indexOf(' ')));
            a=(cbxemp.getSelectedItem().toString());
            ps.setString(4, a.substring(0,a.indexOf(' ')));
            a=(cbxser.getSelectedItem().toString());
            ps.setString(5, a.substring(0,a.indexOf(' ')));
            a=(cbxesp.getSelectedItem().toString());
            ps.setString(6, a.substring(0,a.indexOf(' ')));
            int res = ps.executeUpdate();
            if(res>0){
                JOptionPane.showMessageDialog(null, "Cuenta cita modificado"); //Hospital modificado
                limpiarCaja();
            }
            else{
                JOptionPane.showMessageDialog(null, "Error al Modificar Cuienta cita");
                limpiarCaja();
            }
        con.close();
        }
        
        catch (Exception e) {
            System.err.println(e);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbxmed = new javax.swing.JComboBox<>();
        cbxmat = new javax.swing.JComboBox<>();
        cbxemp = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        cbxser = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        cbxesp = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        txtcita = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Id Cuenta cita");

        jLabel2.setText("Id Cita");

        jLabel3.setText("Id medicamento");

        jLabel4.setText("Id material");

        jLabel5.setText("id empleado");

        jLabel6.setText("id servicios");

        jLabel7.setText("id especialidad");

        jButton2.setText("Buscar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Actualizar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Eliminar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Limpiar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbxmed, 0, 173, Short.MAX_VALUE)
                            .addComponent(cbxmat, 0, 173, Short.MAX_VALUE)
                            .addComponent(cbxemp, 0, 173, Short.MAX_VALUE)
                            .addComponent(cbxser, 0, 173, Short.MAX_VALUE)
                            .addComponent(cbxesp, 0, 173, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtid)
                                    .addComponent(txtcita, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGap(18, 18, 18)
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(jButton3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jButton4)
                                .addGap(18, 18, 18)
                                .addComponent(jButton5)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtcita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(cbxmed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbxmat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cbxemp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cbxser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cbxesp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        buscarDatos();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            actualizarDatos();
        } catch (SQLException ex) {
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        eliminarDatos();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        limpiarCaja();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            guardarDatos();
        } catch (SQLException ex) {
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxemp;
    private javax.swing.JComboBox<String> cbxesp;
    private javax.swing.JComboBox<String> cbxmat;
    private javax.swing.JComboBox<String> cbxmed;
    private javax.swing.JComboBox<String> cbxser;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField txtcita;
    private javax.swing.JTextField txtid;
    // End of variables declaration//GEN-END:variables
}
